package com.example.battlestats;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BattleStatsApplicationTests {

	@Test
	void contextLoads() {
	}

}
